/** Automatically generated file. DO NOT MODIFY */
package com.azinova.splash;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}